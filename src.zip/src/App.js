import MainPage from './Pages/MainPage';
import "./App.css";
import { UserDataProvider } from "./Context/dashboard-context";

function App() {
  return (
    <>
      <UserDataProvider>
        <MainPage />
      </UserDataProvider>
    </>
  );
}

export default App;
