import React from 'react'

function HideColumnsPopup() {
    return (
        <div>HideColumnsPopup</div>
    )
}

export default HideColumnsPopup