import React from 'react'
import { Grid } from '@mui/material'

function AddPage() {
    return (
        <>
            <Grid container justifyContent="center">
                <Grid item xs={12} style={{ width: "100vw" }}>
                    <div>Addpage</div>
                </Grid>
            </Grid>
        </>
    )
}

export default AddPage