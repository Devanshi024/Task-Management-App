import React from 'react'
import { useContext, useState } from 'react'
import "../Css/MainPage.css"
import SubHeader from './SubHeader'
import Header from "./Header"
import { Divider, Grid } from '@mui/material'
import TablePage from './TablePage'
import { userData } from "../Context/dashboard-context"
import AddPage from './AddPage'
import Boardpage from './Boardpage'



function MainPage() {
    const { state } = useContext(userData)
    const [active, setActive] = useState('Table');

    const [flagDeleteOpen, setFlagDeleteOpen] = useState(false);
    const [anchorElDelete, setAnchorElDelete] = useState(null);
    const [localColNameToHide, setLocalColNameToHide] = useState({
        'task_name': false,
        'assigned': false,
        'status': false,
        'priority': false,
        'start_date': false,
        'end_date': false
    });

    const handleDeletePopup = (event) => {
        setAnchorElDelete(event.currentTarget);
        setFlagDeleteOpen(true);
    };

    const handleClose = () => {
        setAnchorElDelete(null);
        setFlagDeleteOpen(false);
    };

    const renderPage = () => {
        switch (active) {
            case 'Table':
                return <TablePage flagDeleteOpen={flagDeleteOpen} setFlagDeleteOpen={setFlagDeleteOpen} 
                anchorElDelete={anchorElDelete} handleClose={handleClose}
                 setLocalColNameToHide={setLocalColNameToHide} localColNameToHide={localColNameToHide}/>
            case 'Board':
                return <Boardpage />
            case 'Add':
                return <AddPage />
        }
    }
    return (
        <>
            <Grid container className='mainpage-container'>
                <Grid item xs={1}></Grid>
                <Grid item xs={10} className='main-page-center-item'>
                    <Grid container style={{ margin: '0 auto', alignItems: "center", justifyContent: 'center' }}>
                        <Grid item xs={12}>
                            <Header />
                        </Grid>
                        <Grid item xs={12}>
                            <Divider />
                            <SubHeader setActive={setActive} active={active}  setLocalColNameToHide={setLocalColNameToHide} localColNameToHide={localColNameToHide} />
                        </Grid>
                        <Grid item xs={12}>
                            {renderPage()}
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item xs={1}></Grid>
            </Grid >
        </>
    )
}

export default MainPage